export const PORT = 5555;

export const mongoDBURL = 'mongodb+srv://root:root@book-store-mern.rq8xp79.mongodb.net/books-collection?retryWrites=true&w=majority&appName=Book-Store-MERN'