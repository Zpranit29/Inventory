import express, { request } from "express";
import {PORT , mongoDBURL} from "./config.js";
// config.js is used to listen to the PORT
import mongoose from "mongoose";
import {Book} from "./models/bookModel.js";
import booksRoute from "./routes/booksRoute.js";
import cors from 'cors';

const app = express();

//Middleware for parsing request body
app.use(express.json());

//Middleware for handling cors policy
//Option 1 Allow all origins with default of Cors
app.use(cors());

//Option 2 Allow custom origins
// app.use(
//     cors({
//         origin : "https://localhost:3000",
//         methods : ['GET' , 'PUT' , 'POST' , 'DELETE'],
//         allowedHeaders : ['Content-Type'],
//     })
// );

//function for listening the PORT
// app.listen(PORT , () =>{
//     console.log(`App is listening on PORT ${PORT}`)
// });

//creating http route as we are getting status code 404 on running app without it

//i want express server to run only if my database connection is successful

app.get('/' , (request,response) => {
    console.log(request);
    return response.status(234).send('Welcome to MERN Stack');
});

app.use('/books',booksRoute);

mongoose.connect(mongoDBURL)
.then( () => {
    console.log("App connected to database");
    // app.get('/' , (request,response) => {
    //     console.log(request);
    //     return response.status(234).send('Welcome to MERN Stack');
    // });
    app.listen(PORT , () =>{
        console.log(`App is listening on PORT ${PORT}`)
    });
})
.catch((error) => {
    console.log(error);
})

